package cards.algorithms.parties;

import cards.generator.Card;

public class Party {
  public double success;
  public double fails;
  public Card lastStatus;

  public Party() {
    this.success = 0.0;
    this.fails = 0.0;
    this.lastStatus = null;
  }

  public Party(Card card) {
    this.success = 0;
    this.fails = 0;
    this.lastStatus = card;
  }
}
