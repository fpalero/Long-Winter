package cards.algorithms;

import cards.algorithms.parties.Party;
import cards.generator.Card;
import cards.generator.CardType;
import java.util.Random;

public class Algorithm1 {
  public Party barones;
  public Party pobladores;
  public Party lobos;
  public Party arquitectos;

  public Algorithm1() {
    init();
  }

  public void init() {
    Random r = new Random(System.currentTimeMillis());
    this.barones = new Party(new Card(CardType.BARONES, r.nextInt(12)));
    this.pobladores = new Party(new Card(CardType.POBLADORES, r.nextInt(12)));
    this.lobos = new Party(new Card(CardType.LOBOS, r.nextInt(12)));
    this.arquitectos = new Party(new Card(CardType.ARQUITECTOS, r.nextInt(12)));
  }

  public void calculateStatus(Card card) {
    if (card.type.equals(CardType.POBLADORES)) {
      pobladoresStatus(card);
    }

    if (card.type.equals(CardType.BARONES)) {
      baronesStatus(card);
    }

    if (card.type.equals(CardType.ARQUITECTOS)) {
      arquitectosStatus(card);
    }

    if (card.type.equals(CardType.LOBOS)) {
      lobosStatus(card);
    }
  }

  public void lobosStatus(Card card) {

    if(card.number < this.pobladores.lastStatus.number &&
        card.number < this.barones.lastStatus.number ) {
      this.lobos.fails++;
    }
    else if(card.number > this.pobladores.lastStatus.number &&
        card.number > this.barones.lastStatus.number ) {
      this.lobos.success++;
    }

    this.lobos.lastStatus = card;
  }

  public void arquitectosStatus(Card card) {
    if(card.number < this.pobladores.lastStatus.number &&
        card.number < this.barones.lastStatus.number ) {
      this.arquitectos.fails++;
    }
    else if(card.number > this.pobladores.lastStatus.number &&
        card.number > this.barones.lastStatus.number ) {
      this.arquitectos.success++;
    }
    this.arquitectos.lastStatus = card;
  }

  public void pobladoresStatus(Card card) {

    if (card.number < this.lobos.lastStatus.number &&
            card.number < this.arquitectos.lastStatus.number) {
      this.pobladores.success = Math.max(0,this.pobladores.success--);
      this.pobladores.fails++;
//
//      this.arquitectos.success++;
//      this.lobos.success++;
    }
    else if (card.number < this.barones.lastStatus.number &&
        (card.number < this.lobos.lastStatus.number ||
            card.number < this.arquitectos.lastStatus.number)) {
      this.pobladores.success = Math.max(0,this.pobladores.success--);
      this.pobladores.fails++;
    }
    else if (card.number > this.barones.lastStatus.number &&
        (card.number > this.lobos.lastStatus.number ||
            card.number > this.arquitectos.lastStatus.number)) {
      this.pobladores.success++;
      this.pobladores.fails = Math.max(0,this.pobladores.fails--);
    }
    else if (card.number > this.barones.lastStatus.number) {
      this.pobladores.success++;
    } else if (card.number < this.barones.lastStatus.number) {
      this.pobladores.fails++;
    }

    this.pobladores.lastStatus = card;
  }

  public void baronesStatus(Card card) {
    if (card.number < this.lobos.lastStatus.number &&
        card.number < this.arquitectos.lastStatus.number) {
      this.barones.success = Math.max(0,this.barones.success--);
      this.barones.fails++;
//
//      this.arquitectos.success++;
//      this.lobos.success++;
    }
    else if (card.number < this.barones.lastStatus.number &&
        (card.number < this.lobos.lastStatus.number ||
            card.number < this.arquitectos.lastStatus.number)) {
      this.barones.success = Math.max(0,this.barones.success--);
      this.barones.fails++;
    }
    else if (card.number > this.pobladores.lastStatus.number &&
        (card.number > this.lobos.lastStatus.number ||
            card.number > this.arquitectos.lastStatus.number)) {
      this.barones.success++;
      this.barones.fails = Math.max(0,this.barones.fails--);
    }
    else if (card.number > this.pobladores.lastStatus.number) {
      this.barones.success++;
    } else if (card.number < this.pobladores.lastStatus.number) {
      this.barones.fails++;
    }

    this.barones.lastStatus = card;
  }

  @Override public String toString() {
    return String.format(
        "Pobladores S: %d F: %d Barones S: %d F: %d Lobos S: %d F: %d Arquitectos S: %d F: %d ",
        pobladores.success, pobladores.fails,
        barones.success, barones.fails,
        lobos.success, lobos.fails,
        arquitectos.success, arquitectos.fails
    );
  }
}
