package cards.generator;

public class CardType {
  public static String ARQUITECTOS = "ARQUITECTOS";
  public static String LOBOS = "LOBOS";
  public static String POBLADORES = "POBLADORES";
  public static String BARONES = "BARONES";

}
